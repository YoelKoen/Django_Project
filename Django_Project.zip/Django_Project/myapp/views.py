# myapp/views.py
from django.shortcuts import render, redirect, get_object_or_404
from .models import Item

def index(request):
    if request.method == 'POST':
        # This code runs when the user submits the form

        # 1. Get the data from the form input named 'item_text'
        item_text = request.POST.get('item_text')

        # 2. Create a new Item object and save it to the database
        Item.objects.create(text=item_text)

        # 3. Redirect the user back to the home page after saving
        return redirect('/') 

    # This code runs for a GET request (when just loading the page)
    all_items = Item.objects.all()
    context = {
        'items': all_items,
    }
    return render(request, "myapp/index.html", context)

def delete_item(request, item_id):
    # Use get_object_or_404 to safely retrieve the item, or return a 404 error if not found
    item = get_object_or_404(Item, id=item_id)
    
    # Check if the request is POST (form submission) for security
    if request.method == 'POST':
        item.delete()
    
    # Redirect back to the home page
    return redirect('/')