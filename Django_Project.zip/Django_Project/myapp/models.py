# myapp/models.py
from django.db import models

class Item(models.Model):
    # This field will store the text content of the item
    text = models.CharField(max_length=200)

    def __str__(self):
        # This is what will be displayed in the Django Admin
        return self.text